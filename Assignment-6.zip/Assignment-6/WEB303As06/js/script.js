
$(document). ready(function(e){
 
    e.preventDefault();
    
    $(".accordian-1").on('click','.accr-1-1', function (e) {
        e.preventDefault();
        $(this)
        .next('.acpr-1')
        .not('animated')
        .sideToggle();
    });

    
    $(".accordian").on('click','.accr-1-2', function (e) {
        e.preventDefault();
        $(this)
        .next('.acpr-2')
        .not('animated')
        .sideToggle();
    });
})

